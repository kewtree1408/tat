(function ($) {
  
  FormInput = Backbone.Model.extend({
    name: "",
  });
  
  FormInputs = Backbone.Collection.extend({
    initialize: function (models, options) {
      this.bind("add", options.view.add);
      //Listen for new additions to the collection and call a view function if so
    }
  });
  
  AppView = Backbone.View.extend({
    el: $("body"),
    initialize: function () {
      this.route_form = new FormInputs( 'route_form', { view: this });
      this.search_form = new FormInputs( 'search_form', { view: this });
    },
    events: {
      "click #route_form":  "showPrompt",
    },
    showPrompt: function () {
      var friend_name = prompt("Who is your friend?");
      var friend_model = new FormInput({ name: friend_name });
      //Add a new friend model to our friend collection
      this.route_form.add( friend_model );
    },
    addFriendLi: function (model) {
      //The parameter passed is a reference to the model that was added
      $("#tbody").append("<td>" + model.get('name') + "</td>");
      //Use .get to receive attributes of the model
    }
  });
  
  var appview = new AppView;
})(jQuery);