var BaseView = require('views/base-view');

module.exports = BaseView.extend({

    name: 'error',

    tpl: require('tpl/error')

});